import { MapPin, Building2, Clock } from 'lucide-react';

const jobs = [
  {
    title: 'Senior Software Engineer',
    company: 'Tech Innovations Inc',
    location: 'San Francisco, CA',
    type: 'Full-time',
    salary: '$120k - $180k'
  },
  {
    title: 'Product Manager',
    company: 'Digital Solutions Co',
    location: 'New York, NY',
    type: 'Full-time',
    salary: '$100k - $150k'
  },
  {
    title: 'UX Designer',
    company: 'Creative Agency',
    location: 'Remote',
    type: 'Contract',
    salary: '$80k - $120k'
  },
  {
    title: 'Marketing Director',
    company: 'Global Brands Ltd',
    location: 'Chicago, IL',
    type: 'Full-time',
    salary: '$90k - $140k'
  }
];

export default function JobListings() {
  return (
    <section id="jobs" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900">Featured Positions</h2>
          <p className="mt-4 text-xl text-gray-600">
            Explore our latest job opportunities
          </p>
        </div>

        <div className="mt-12 grid gap-8">
          {jobs.map((job, index) => (
            <div
              key={index}
              className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow p-6"
            >
              <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                <div>
                  <h3 className="text-xl font-semibold text-gray-900">{job.title}</h3>
                  <div className="mt-2 flex items-center text-gray-600">
                    <Building2 className="h-4 w-4 mr-2" />
                    {job.company}
                  </div>
                  <div className="mt-2 flex items-center text-gray-600">
                    <MapPin className="h-4 w-4 mr-2" />
                    {job.location}
                  </div>
                  <div className="mt-2 flex items-center text-gray-600">
                    <Clock className="h-4 w-4 mr-2" />
                    {job.type}
                  </div>
                </div>
                <div className="mt-4 md:mt-0">
                  <span className="text-lg font-medium text-gray-900">{job.salary}</span>
                  <button className="mt-2 w-full md:w-auto px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors">
                    Apply Now
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <button className="px-6 py-3 bg-white text-blue-600 rounded-md border border-blue-600 hover:bg-blue-50 transition-colors">
            View All Positions
          </button>
        </div>
      </div>
    </section>
  );
}