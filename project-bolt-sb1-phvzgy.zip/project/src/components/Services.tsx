import { Briefcase, Users, Sparkles, Trophy } from 'lucide-react';

const services = [
  {
    icon: Briefcase,
    title: 'Permanent Placement',
    description: 'Find your perfect long-term career match with our expert placement services.'
  },
  {
    icon: Sparkles,
    title: 'Skills Assessment',
    description: 'Comprehensive evaluation of candidates to ensure the perfect job fit.'
  },
  {
    icon: Trophy,
    title: 'Talent Development',
    description: 'Professional development and training programs for career growth.'
  },
  {
    icon: Users,
    title: 'HR Consulting',
    description: 'Strategic HR solutions to optimize your recruitment and retention processes.'
  }
];

export default function Services() {
  return (
    <section id="services" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900">Our Services</h2>
          <p className="mt-4 text-xl text-gray-600">
            Expert permanent recruitment solutions tailored to your needs
          </p>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
          {services.map((service, index) => (
            <div
              key={index}
              className="relative p-6 bg-white rounded-lg border border-gray-200 hover:shadow-lg transition-shadow"
            >
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                <service.icon className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900">{service.title}</h3>
              <p className="mt-2 text-gray-600">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}