import { Users } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center">
              <Users className="h-8 w-8 text-blue-400" />
              <span className="ml-2 text-xl font-bold">Nexxus Solution</span>
            </div>
            <p className="mt-4 text-gray-400">
              Connecting exceptional talent with outstanding opportunities since 2024.
            </p>
            <div className="mt-4 text-gray-400">
              <a href="mailto:nexxussoution@gmail.com" className="hover:text-white">
                nexxussoution@gmail.com
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="#home" className="text-gray-400 hover:text-white">Home</a></li>
              <li><a href="#services" className="text-gray-400 hover:text-white">Services</a></li>
              <li><a href="#jobs" className="text-gray-400 hover:text-white">Jobs</a></li>
              <li><a href="#about" className="text-gray-400 hover:text-white">About</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Services</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-400 hover:text-white">Permanent Placement</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white">Skills Assessment</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white">Talent Development</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white">HR Consulting</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Legal</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-400 hover:text-white">Privacy Policy</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white">Terms of Service</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white">Cookie Policy</a></li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-gray-800 text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} Nexxus Solution. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}